//
//  ApiManager.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import Foundation
import Alamofire

class MyAPI{
    
    
    func callJokes(params: @escaping(Result<[JokeModal],Error>)-> Void){
        
        let url = "https://official-joke-api.appspot.com/jokes/random/25"
        
        AF.request(url).responseDecodable(of:[JokeModal].self){
            
            response in switch response.result {
            case .success(let success):
                params(.success(success))
            case .failure(let failure):
                params(.failure(failure))
            }
            
        }
        
    }
    
}
