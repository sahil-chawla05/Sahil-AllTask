//
//  JokesModel.swift
//  RudraJokes
//
//  Created by Hiren Masaliya on 22/10/24.
//

import Foundation

struct JokesModel : Codable {
    var id : Int
    var type : String
    var setup : String
    var punchline : String
}
