//
//  ViewController.swift
//  RudraJokes
//
//  Created by Hiren Masaliya on 22/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var Jokes : [JokesModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupTableView()
    }

    override func viewWillAppear(_ animated: Bool) {
        ApiServices().jokeApi { res in
            switch res {
            case .success(let data):
                self.Jokes.append(contentsOf: data)
                self.tableView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }

}


extension ViewController : UITableViewDelegate, UITableViewDataSource{
    
    func setupTableView(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "JokesCell", bundle: nil), forCellReuseIdentifier: "JokesCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JokesCell", for: indexPath) as! JokesCell
        
        cell.lblSetup.text = Jokes[indexPath.row].setup
        
        return cell
    }
    
    
}

