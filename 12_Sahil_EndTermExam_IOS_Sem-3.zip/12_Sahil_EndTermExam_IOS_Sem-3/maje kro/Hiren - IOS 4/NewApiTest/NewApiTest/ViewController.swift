//
//  ViewController.swift
//  NewApiTest
//
//  Created by Hiren Masaliya on 08/10/24.
//

import UIKit

class ViewController: UIViewController {
    
    var catsList : [NewApiModel] = []
    
    var cat : NewApiModel!

    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if catsList.isEmpty {
            ApiService().callApi { res in
                switch res {
                case .success(let data):
                    self.catsList.append(contentsOf: data)
                    self.tableView.reloadData()
                case .failure(let failure):
                    print(failure)
                }
            }
        }
        
        
    }


}

extension ViewController : UITableViewDataSource,UITableViewDelegate{
    
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "JokeCell", bundle: nil), forCellReuseIdentifier: "JokeCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JokeCell", for: indexPath) as! JokeCell
        cell.lblId.text = String(catsList[indexPath.row].id)
        cell.lblName.text = catsList[indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cat = catsList[indexPath.row]
        performSegue(withIdentifier: "SecoundVC", sender: self)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SecoundVC" {
            if let data = segue.destination as? SecoundVC{
                data.cats = cat
            }
        }
    }
}

