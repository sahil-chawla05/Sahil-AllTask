//
//  JokeCell.swift
//  JokeApiDataDemo
//
//  Created by Hiren Masaliya on 12/10/24.
//

import UIKit

class JokeCell: UITableViewCell {
    @IBOutlet weak var lblSetup: UILabel!
    
    @IBOutlet weak var lblPunchLine: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
