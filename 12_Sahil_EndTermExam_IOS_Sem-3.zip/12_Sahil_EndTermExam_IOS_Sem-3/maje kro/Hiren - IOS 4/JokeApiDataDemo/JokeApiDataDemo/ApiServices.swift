//
//  ApiServices.swift
//  JokeApiDataDemo
//
//  Created by Hiren Masaliya on 12/10/24.
//

import Foundation
import Alamofire

class ApiServices {
    
    let urlstr = "https://official-joke-api.appspot.com/jokes/random/25"
    
    func jokeApi(cv: @escaping(Result<[JokeModel],Error>)->Void){
        AF.request(urlstr).responseDecodable(of: [JokeModel].self) { response in
            switch response.result {
            case .success(let data):
                cv(.success(data))
            case .failure(let error):
                cv(.failure(error))
            }
        }
    }
}
