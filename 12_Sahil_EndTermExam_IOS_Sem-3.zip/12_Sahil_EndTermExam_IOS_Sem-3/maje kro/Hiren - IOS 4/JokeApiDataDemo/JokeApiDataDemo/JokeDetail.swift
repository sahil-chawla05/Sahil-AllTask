//
//  JokeDetail.swift
//  JokeApiDataDemo
//
//  Created by Hiren Masaliya on 12/10/24.
//

import UIKit

class JokeDetail: UIViewController {

    @IBOutlet weak var lblPunchLine: UILabel!
    @IBOutlet weak var lblSetupLine: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblId: UILabel!
    
    var jokes : JokeModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblId.text = String(jokes.id)
        lblType.text = jokes.type
        lblPunchLine.text = jokes.punchline
        lblSetupLine.text = jokes.setup
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
