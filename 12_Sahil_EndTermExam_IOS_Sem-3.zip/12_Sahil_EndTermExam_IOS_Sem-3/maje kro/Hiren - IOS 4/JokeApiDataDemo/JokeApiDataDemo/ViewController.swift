//
//  ViewController.swift
//  JokeApiDataDemo
//
//  Created by Hiren Masaliya on 12/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var loading: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    var joke : [JokeModel] = []
    
    var currentJoke : JokeModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loading.startAnimating()
        ApiServices().jokeApi { res in
            switch res {
            case .success(let data):
                self.joke.append(contentsOf: data)
                self.tableView.reloadData()
                self.loading.stopAnimating()
                self.loading.isHidden = true
            case .failure(let error):
                print(error)
            }
        }
    }


}


extension ViewController : UITableViewDataSource,UITableViewDelegate{
    
    func setupTableView(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "JokeCell", bundle: nil), forCellReuseIdentifier: "JokeCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return joke.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JokeCell", for: indexPath) as! JokeCell
        
        cell.lblSetup.text = joke[indexPath.row].setup
        cell.lblPunchLine.text = joke[indexPath.row].punchline
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentJoke = joke[indexPath.row]
        performSegue(withIdentifier: "JokeDetail", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "JokeDetail"{
            if let data = segue.destination as? JokeDetail{
                data.jokes = currentJoke
            }
        }
    }
}

