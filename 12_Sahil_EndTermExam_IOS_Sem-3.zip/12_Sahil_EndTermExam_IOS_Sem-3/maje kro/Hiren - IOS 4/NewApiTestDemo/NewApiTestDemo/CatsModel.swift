//
//  CatsModel.swift
//  NewApiTestDemo
//
//  Created by Hiren Masaliya on 08/10/24.
//

import Foundation


struct CatsModel : Codable{
    let id : Int
    let name : String
    let origin : String
    let colors : [String]
    let description : String
    let image : String
}
