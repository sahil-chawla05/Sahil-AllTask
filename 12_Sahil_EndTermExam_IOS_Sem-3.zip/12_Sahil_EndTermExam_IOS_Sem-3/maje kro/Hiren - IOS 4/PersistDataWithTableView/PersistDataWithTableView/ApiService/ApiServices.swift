//
//  ApiServices.swift
//  PersistDataWithTableView
//
//  Created by Hiren Masaliya on 03/10/24.
//

import Foundation
import Alamofire

class ApiServices {
    
    func CallJokeData(cv: @escaping(Result<[JokeModel],Error>)-> Void) {
        let url = "https://official-joke-api.appspot.com/jokes/random/25"
        AF.request(url).responseDecodable(of: [JokeModel].self) { respones in
            switch respones.result {
            case .success(let data):
                cv(.success(data))
            case .failure(let error):
                cv(.failure(error))
            }
        }
    }
}
