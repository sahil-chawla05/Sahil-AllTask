//
//  SecoundVC.swift
//  PersistDataWithTableView
//
//  Created by Hiren Masaliya on 03/10/24.
//

import UIKit

class SecoundVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var Jokes : [JokeModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        var name = UserDefaults.standard.string(forKey: "Name")
        navigationItem.title = name!
        
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        ApiServices().CallJokeData { res in
            switch res {
            case .success(let data):
                self.Jokes.append(contentsOf: data)
                self.tableView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension SecoundVC : UITableViewDelegate,UITableViewDataSource{
    
    func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        
        cell.lblSetup.text = Jokes[indexPath.row].setup
        cell.lblPunchLine.text = Jokes[indexPath.row].punchline
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
}
