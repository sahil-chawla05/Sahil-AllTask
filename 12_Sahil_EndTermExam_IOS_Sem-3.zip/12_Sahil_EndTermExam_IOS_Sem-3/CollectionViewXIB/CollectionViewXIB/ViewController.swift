import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var jcv: UICollectionView!
    
    var joke: [JokeModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setCollectionView()
        fetchData()
    }

    func fetchData() {
        let urlStr = "https://official-joke-api.appspot.com/jokes/random/25"
        
        if let url = URL(string: urlStr) {
            let session = URLSession.shared
            let dataTask = session.dataTask(with: url) { data, response, error in
                guard let jokeData = data else { return }
                
                do {
                    let jokes = try JSONDecoder().decode([JokeModel].self, from: jokeData)
                    
                    self.joke.append(contentsOf: jokes)
                    
                    DispatchQueue.main.async {
                        self.jcv.reloadData()
                    }
                    
                } catch {
                    print("Error decoding JSON:", error)
                }
            }
            dataTask.resume()
        }
    }
}

struct JokeModel: Codable {
    let id: Int
    let type: String
    let setup: String
    let punchline: String
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func setCollectionView() {
        jcv.delegate = self
        jcv.dataSource = self
        
        // Register the custom collection view cell
        let collectionNIB = UINib(nibName: "CollectionVC", bundle: nil)
        jcv.register(collectionNIB, forCellWithReuseIdentifier: "CollectionVC")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return joke.count  // Return the number of jokes
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionVC", for: indexPath) as! CollectionVC
        
        let jokeItem = joke[indexPath.row]
        cell.setUpLabel.text = jokeItem.setup
        cell.punchlineLabel.text = jokeItem.punchline
        
        return cell
    }

    
}
