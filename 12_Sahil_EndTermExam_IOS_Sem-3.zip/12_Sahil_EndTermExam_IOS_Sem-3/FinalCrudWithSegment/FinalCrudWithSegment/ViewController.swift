//
//  ViewController.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    
    @IBOutlet weak var seg_ol: UISegmentedControl!
    @IBOutlet weak var apiTable: UITableView!
    @IBOutlet weak var loader: UIActivityIndicatorView!
    @IBOutlet weak var readTable: UITableView!
    
    
   
    
    var jokes:[JokeModal] = []
    var storeJokes : [JokeModal] = []
    var selectedJoke : JokeModal!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchJokes()
        setup()
       
    }

    override func viewWillAppear(_ animated: Bool) {
        refreshUi()
        readFromCoreData()
    }
   
    
    
    func refreshUi(){
        if seg_ol.selectedSegmentIndex == 0{
            apiTable.isHidden = false
            readTable.isHidden = true
            
            DispatchQueue.main.async{
                self.apiTable.reloadData()
            }
            
        }
        else if seg_ol.selectedSegmentIndex == 1{
            apiTable.isHidden = true
            readTable.isHidden = false
            
            DispatchQueue.main.async{
                self.readTable.reloadData()
            }
        }
    }
    
    
    @IBAction func segMenttap(_ sender: Any) {
        refreshUi()
        readFromCoreData()
    }
    
    
    @IBAction func goToFormForAddData(_ sender: Any) {
        performSegue(withIdentifier: "gotoFormVc", sender: self)
    }
    
    
}


extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func setup(){
        apiTable.delegate = self
        apiTable.dataSource = self
        apiTable.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        
        readTable.delegate = self
       readTable.dataSource = self
        readTable.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if seg_ol.selectedSegmentIndex == 0 {
               return jokes.count
           } else {
               return storeJokes.count
           }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
       
        if tableView == apiTable {
        
            let cell = apiTable.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
            
            cell.idLbl.text = String(jokes[indexPath.row].id)
            cell.typeLbl.text = jokes[indexPath.row].type
            cell.setupLbl.text = jokes[indexPath.row].setup
            cell.punchlineLbl.text = jokes[indexPath.row].punchline
        
             return cell
        }
        
        else {
            let cell = readTable.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
            
            cell.idLbl.text = String(storeJokes[indexPath.row].id)
            cell.typeLbl.text = storeJokes[indexPath.row].type
            cell.setupLbl.text = storeJokes[indexPath.row].setup
            cell.punchlineLbl.text = storeJokes[indexPath.row].punchline
            
            return cell
         }
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == apiTable{
            selectedJoke = jokes[indexPath.row]
            addToCoreData(dataObject: JokeModal(id: selectedJoke.id, type: selectedJoke.type, setup: selectedJoke.setup, punchline: selectedJoke.punchline))
        }
    
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
      
        if tableView == readTable{
            
            let deleteAction = UIContextualAction(style: .destructive, title: "Delete"){(action,view,completionHandler) in
                
                self.selectedJoke = self.storeJokes[indexPath.row]
                self.deleteFromCoreData(joke: self.selectedJoke)
                self.storeJokes.remove(at: indexPath.row)
                self.readTable.deleteRows(at: [indexPath], with: .fade)
                completionHandler(true)
            }
            
            
            let updateAction = UIContextualAction(style: .destructive, title: "update"){(action,view,completionHandler) in
                
                self.selectedJoke = self.storeJokes[indexPath.row]
                self.performSegue(withIdentifier: "navigateToUpdateVc", sender: self)
                completionHandler(true)
                
            }
            
            deleteAction.backgroundColor = .red
            updateAction.backgroundColor = .blue
            
            let configuration = UISwipeActionsConfiguration(actions: [deleteAction,updateAction])
            
            return configuration
            
        }
        return nil
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "navigateToUpdateVc"{
            if let updateVc = segue.destination as? UpdateVc{
                updateVc.currentjoke = selectedJoke
            }
        }
    }
    
    
}


extension ViewController {
    
    func fetchJokes(){
        
        loader.startAnimating()
        
        MyAPI().callJokes{
            
            result in switch result {
            case .success(let success):
                self.setup()
                self.jokes.append(contentsOf: success)
                
                DispatchQueue.main.async {
                    self.apiTable.reloadData()
                }
        
                self.loader.stopAnimating()
                self.loader.isHidden = true
                
                
            case .failure(let failure):
               debugPrint(failure)
                
                self.loader.stopAnimating()
                self.loader.isHidden = true
                
            }
        }
    }
    
    
    
    func addToCoreData(dataObject:JokeModal){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else{return}
        
        let managedContext = delegate.persistentContainer.viewContext
        
        guard let jokeEntity = NSEntityDescription.entity(forEntityName: "Jokes", in: managedContext) else{return}
        
        let joke = NSManagedObject(entity: jokeEntity, insertInto: managedContext)
        
        joke.setValue(dataObject.id, forKey: "id")
        joke.setValue(dataObject.type, forKey: "type")
        joke.setValue(dataObject.setup , forKey: "setup")
        joke.setValue(dataObject.punchline, forKey: "punchline")
        
        
        do{
            try managedContext.save()
            
            debugPrint("Data Saved.!")
            
            let alert = UIAlertController(title: "Success", message: "data Added Successfully..!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        catch let err as NSError{
            debugPrint("Error Occured :\(err)")
        }
    }
    
    
    func readFromCoreData(){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else{return}
        
        let managedContext = delegate.persistentContainer.viewContext
       
        
        let fetchReuest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        do{
            let res = try managedContext.fetch(fetchReuest)
            
            debugPrint("Data fetched Successfully")
            storeJokes.removeAll()
            
            for data in res as! [NSManagedObject]{
                
                let jid  = data.value(forKey: "id") as! Int
                let jtype = data.value(forKey: "type") as! String
                let jsetup = data.value(forKey: "setup") as! String
                let jpunchline = data.value(forKey: "punchline") as! String
                
                storeJokes.append(JokeModal(id: jid, type: jtype, setup: jsetup, punchline: jpunchline))
            }
            
        
        }
        catch let err as NSError{
            debugPrint("Error Occured :\(err)")
        }
    }
    
    
    
    
    func deleteFromCoreData(joke:JokeModal){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else{return}
        
        let managedContext = delegate.persistentContainer.viewContext
       
        
        let fetchReuest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        fetchReuest.predicate = NSPredicate(format: "id == %d",joke.id)
        
        do{
            let res = try managedContext.fetch(fetchReuest)
           
            if let jokeTodelete  = res.first as? NSManagedObject{
                managedContext.delete(jokeTodelete)
                try managedContext.save()
            
                
                let alert = UIAlertController(title: "Success", message: "data Deleted  Successfully..!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
            }
            
        
        }
        catch let err as NSError{
            debugPrint("Error Occured :\(err)")
        }
    }
    
    

    
}
