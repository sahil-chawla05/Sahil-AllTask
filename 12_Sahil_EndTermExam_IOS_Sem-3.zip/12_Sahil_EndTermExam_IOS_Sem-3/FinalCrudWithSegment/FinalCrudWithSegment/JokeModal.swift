//
//  JokeModal.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import Foundation
struct JokeModal : Codable{
    var id : Int
    var type : String
    var setup : String
    var punchline : String
}
