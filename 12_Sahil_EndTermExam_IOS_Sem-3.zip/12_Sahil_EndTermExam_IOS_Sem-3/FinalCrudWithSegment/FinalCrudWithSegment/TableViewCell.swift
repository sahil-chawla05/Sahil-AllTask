//
//  TableViewCell.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var idLbl: UILabel!
    
    @IBOutlet weak var typeLbl: UILabel!
    
    @IBOutlet weak var setupLbl: UILabel!
    
    @IBOutlet weak var punchlineLbl: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
