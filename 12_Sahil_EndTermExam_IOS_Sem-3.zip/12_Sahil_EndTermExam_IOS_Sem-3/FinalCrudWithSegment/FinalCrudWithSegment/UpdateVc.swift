//
//  UpdateVc.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import UIKit
import CoreData

class UpdateVc: UIViewController {


    @IBOutlet weak var type: UITextField!
    @IBOutlet weak var setup: UITextField!
    @IBOutlet weak var punchline: UITextField!
    var currentjoke : JokeModal!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTextfields()
       
    }
    
    func setupTextfields(){
        type.text = currentjoke.type
        setup.text = currentjoke.setup
        punchline.text = currentjoke.punchline
        
    }
    

    @IBAction func updatebtntap(_ sender: Any) {
        
        var utype = type.text!
        var usetup = setup.text!
        var upunch = punchline.text!
        
        
        updateToCoreData(dataObject: JokeModal(id: currentjoke.id, type: utype, setup: usetup, punchline: upunch))
    }
    
    
    func updateToCoreData(dataObject: JokeModal){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let managedContext = delegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        fetchRequest.predicate = NSPredicate(format: "id == %d", dataObject.id)
        
        do{
            
            let res  = try managedContext.fetch(fetchRequest)
            
            if let jokeToupdate = res.first as? NSManagedObject{
                
                jokeToupdate.setValue(dataObject.type, forKey: "type")
                jokeToupdate.setValue(dataObject.setup, forKey: "setup")
                jokeToupdate.setValue(dataObject.punchline, forKey: "punchline")
                
                try managedContext.save()
                
                print("Update Successfully")
                let alert = UIAlertController(title: "Success", message: "data Updated  Successfully..!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
            }
         }
        
        catch let err as NSError{
            debugPrint("Error : \(err)")
        }
        
    }
    
}
