//
//  ViewController.swift
//  UIKit-ColorPicker
//
//  Created by Hiren Masaliya on 13/08/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ColorView: UIView!
    
    @IBOutlet weak var rSlider: UISlider!
    @IBOutlet weak var gSlider: UISlider!
    @IBOutlet weak var bSlider: UISlider!
    @IBOutlet weak var opacitySlider: UISlider!
    
    private var r: CGFloat!
    private var g: CGFloat!
    private var b: CGFloat!
    private var o: CGFloat!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func changeColor(r: CGFloat,g: CGFloat,b: CGFloat,o: CGFloat){
        ColorView.backgroundColor = UIColor(red: r/255, green: g/255, blue: b/255, alpha: o)
    }

    @IBAction func rSliderChanged(_ sender: Any) {
        r = CGFloat(rSlider.value);
        g = CGFloat(gSlider.value);
        b = CGFloat(bSlider.value);
        o = CGFloat(opacitySlider.value);
        changeColor(r: r,g: g,b: b,o: o)
    }
    @IBAction func gSliderChanged(_ sender: Any) {
        r = CGFloat(rSlider.value);
        g = CGFloat(gSlider.value);
        b = CGFloat(bSlider.value);
        o = CGFloat(opacitySlider.value);
        changeColor(r: r,g: g,b: b,o: o)
    }
    @IBAction func bSliderChanged(_ sender: Any) {
        r = CGFloat(rSlider.value);
        g = CGFloat(gSlider.value);
        b = CGFloat(bSlider.value);
        o = CGFloat(opacitySlider.value);
        changeColor(r: r,g: g,b: b,o: o)
    }
    @IBAction func opacitySliderChanged(_ sender: Any) {
        r = CGFloat(rSlider.value);
        g = CGFloat(gSlider.value);
        b = CGFloat(bSlider.value);
        o = CGFloat(opacitySlider.value);
        changeColor(r: r,g: g,b: b,o: o)
    }
    
}

