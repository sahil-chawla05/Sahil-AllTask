//
//  CollectUI.swift
//  CollectionView_Learn
//
//  Created by admin on 01/10/24.
//

import UIKit

class CollectUI: UICollectionViewCell {

    @IBOutlet weak var collectlbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
