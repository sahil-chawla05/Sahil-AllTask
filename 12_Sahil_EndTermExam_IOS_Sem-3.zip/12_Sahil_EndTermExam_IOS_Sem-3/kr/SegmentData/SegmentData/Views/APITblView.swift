//
//  APITblView.swift
//  SegmentData
//
//  Created by admin on 03/12/24.
//

import Foundation
