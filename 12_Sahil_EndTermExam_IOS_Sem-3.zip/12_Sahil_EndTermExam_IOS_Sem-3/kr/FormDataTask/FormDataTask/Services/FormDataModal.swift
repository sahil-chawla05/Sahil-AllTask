//
//  FormDataModal.swift
//  FormDataTask
//
//  Created by admin on 26/11/24.
//

import Foundation


struct FormDataModal : Codable{
    
    let id : Int
    let name : String
    let email : String
    let phone : Int
    let stream : String
}
