//
//  ViewController.swift
//  ApiCallWIthTableView
//
//  Created by Hiren Masaliya on 02/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LoadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var TVJoke: UITableView!
    
    var Jokes : [JokeModel] = []
    
    var currentJoke : JokeModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTable()
        LoadingIndicator.startAnimating()
    }

    override func viewWillAppear(_ animated: Bool) {
        LoadingIndicator.startAnimating()
        ApiSetup().ApiCall { res in
            switch res {
            case .success(let data):
                self.Jokes.append(contentsOf: data)
                self.TVJoke.reloadData()
                self.LoadingIndicator.stopAnimating()
                self.LoadingIndicator.isHidden = true
            case .failure(let error):
                print(error)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DetailsVC"{
            if let data = segue.destination as? DetailsVC{
                data.selectedJoke = currentJoke
            }
        }
    }

}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func setupTable(){
        TVJoke.delegate = self
        TVJoke.dataSource = self
        TVJoke.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TVJoke.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath) as! TVCell
        
        cell.lblSetup.text = Jokes[indexPath.row].setup
        cell.lblPunchline.text = Jokes[indexPath.row].punchline
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentJoke = Jokes[indexPath.row]
        performSegue(withIdentifier: "DetailsVC", sender: self)
    }
    
    
}

