//
//  BookFormVC.swift
//  SegmentData
//
//  Created by admin on 03/12/24.
//
    
import UIKit
import CoreData

class BookFormVC: UIViewController {
    
    
    @IBOutlet weak var booknameTxt: UITextField!
    @IBOutlet weak var bookPageTxt: UITextField!
    @IBOutlet weak var bookISBNtxt: UITextField!
    @IBOutlet weak var bookauthorTxt: UITextField!
    @IBOutlet weak var bookCoverImg: UIImageView!
    
    var bName : String!
    var bAuthorName : String!
    var bISBN : Int?
    var bPageNum : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        
    }
    
    @IBAction func submitBtn(_ sender: Any) {
        
        bName = self.booknameTxt.text
        bAuthorName = self.bookauthorTxt.text
        bISBN = Int(bookISBNtxt.text!)
        bPageNum = Int(bookPageTxt.text!)
        
        insertData(bookObj: BookModal(bookname: bName ,
                                      bookauthor: bAuthorName,
                                      bookisbn: bISBN!,
                                      bookpage: bPageNum!))
        
        
        
    }
   
    
    func insertData(bookObj : BookModal){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = delegate.persistentContainer.viewContext
        guard let insertEntity = NSEntityDescription.entity(forEntityName: "Books", in: managedContext) else { return }
                
        let books = NSManagedObject(entity: insertEntity, insertInto: managedContext)
        
        books.setValue(bookObj.bookname, forKey: "bookname")
        books.setValue(bookObj.bookauthor, forKey: "bookauthor")
        books.setValue(bookObj.bookisbn, forKey: "bookisbn")
        books.setValue(bookObj.bookpage, forKey: "bookpage")
        
        do{
            try managedContext.save()
            debugPrint("Save Successfully...")
            
        }  catch let err as NSError{
            debugPrint("Error...\(err)")
        }
    }
}


