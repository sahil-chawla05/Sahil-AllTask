//
//  BookFormVC.swift
//  SegmentData
//
//  Created by admin on 03/12/24.
//

import UIKit

class BookFormVC: UIViewController {
    
    
    @IBOutlet weak var booknameTxt: UITextField!
    @IBOutlet weak var bookPageTxt: UITextField!
    @IBOutlet weak var bookISBNtxt: UITextField!
    @IBOutlet weak var bookauthorTxt: UITextField!
    @IBOutlet weak var bookCoverImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func submitBtn(_ sender: Any) {
    }
   

}
