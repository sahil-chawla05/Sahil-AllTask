//
//  ViewController.swift
//  SegmentData
//
//  Created by admin on 03/12/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    
    @IBOutlet weak var addBookData: UIImageView!
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
 
    @IBOutlet weak var apiTblData: UITableView!
    var oneselectIndex : Int = 1
    var jokeArr : [JokeModal] = []
    var saveJokes : [JokeSaveModal] = []
    
    
    override func viewWillAppear(_ animated: Bool) {
        apiCallService().apiCall { result in
            switch result{
            case .success(let data):
                self.jokeArr.append(contentsOf: data)
                self.apiTblData.reloadData()
                
            case .failure(let error):
                debugPrint("Error...\(error)")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        readData()
        
        
       
    }

    
    
    @IBAction func navigateBtwnTbl(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
               self.oneselectIndex = 1
           }
           else {
               self.oneselectIndex = 2
               readData()

           }
           self.apiTblData.reloadData()
    }
    
}


extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func setUp(){
            apiTblData.delegate = self
            apiTblData.dataSource = self
            apiTblData.register(UINib(nibName: "apiDataCell", bundle: nil), forCellReuseIdentifier: "apiDataCell")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if oneselectIndex == 1 {
            return self.jokeArr.count
        }
        else {
            return self.saveJokes.count
        }
    }
    
    
    func readData(){
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = delegate.persistentContainer.viewContext
        let fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        do {
            
            let response = try managedContext.fetch(fetchrequest)
            debugPrint("Fetch data success..")
            
            for data in response as! [NSManagedObject] {
             
                self.saveJokes.append(JokeSaveModal(id: Int(data.value(forKey: "id") as! Int32),
                                            punchline: data.value(forKey: "punchline") as! String,
                                            setup: data.value(forKey: "setup") as! String,
                                            type: data.value(forKey: "type") as! String))
                
                self.apiTblData.reloadData()
                
            }
        }
        catch{
            debugPrint("Error..")
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = apiTblData.dequeueReusableCell(withIdentifier: "apiDataCell", for: indexPath) as! apiDataCell

               if oneselectIndex == 1 {
                   cell.setupLbl.text = jokeArr[indexPath.row].setup
               }
               else {
                   cell.setupLbl.text = saveJokes[indexPath.row].setup
               }

               return cell
    }
    
    func CoreDataFunc(jokeObject : JokeModal){
       
       guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
       let managedContext = delegate.persistentContainer.viewContext
       guard let jokeEntity = NSEntityDescription.entity(forEntityName: "Jokes", in: managedContext) else { return }
       
       let joke = NSManagedObject(entity: jokeEntity, insertInto: managedContext)
       
       joke.setValue(jokeObject.id, forKey: "id")
       joke.setValue(jokeObject.type, forKey: "type")
       joke.setValue(jokeObject.setup, forKey: "setup")
       joke.setValue(jokeObject.punchline, forKey: "punchline")
       
       do{
           try managedContext.save()
           debugPrint("Save Successfully...")
           
       }  catch let err as NSError{
           debugPrint("Error...\(err)")
       }
   }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let joke = jokeArr[indexPath.row]
        CoreDataFunc(jokeObject: joke)
    }
    
}
