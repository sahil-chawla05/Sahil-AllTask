//
//  jokeCell.swift
//  PracticeCRUD
//
//  Created by sanskruti chaudhari on 25/12/24.
//

import UIKit

class jokeCell: UITableViewCell {
    
    
    @IBOutlet weak var punchlineLbl: UILabel!
    @IBOutlet weak var setupLbl: UILabel!
    @IBOutlet weak var idLbl: UILabel!
    
    @IBOutlet weak var typeLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
