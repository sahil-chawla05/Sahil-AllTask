//
//  File.swift
//  PracticeCRUD
//
//  Created by sanskruti chaudhari on 25/12/24.
//

import Foundation

struct jokeModal : Codable {
    let id: String
    let type: String
    let setup: String
    let punchline: String
}

